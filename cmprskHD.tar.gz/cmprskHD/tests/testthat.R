library(testthat)
library(cmprskHD)

test_check("cmprskHD")
